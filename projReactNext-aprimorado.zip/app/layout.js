import '../styles/globals.css'
import { ThemeProvider } from '../context/ThemeContext'
import { AuthProvider } from '../context/AuthContext'

export const metadata = {
  title: 'Sistema de Autenticação - Aprimorado',
}

export default function RootLayout({ children }){
  return (
    <html lang="pt-BR">
      <body>
        <ThemeProvider>
          <AuthProvider>
            {children}
          </AuthProvider>
        </ThemeProvider>
      </body>
    </html>
  )
}
