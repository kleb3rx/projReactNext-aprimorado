'use client'
import React, { useState } from 'react'
import Cookies from 'js-cookie'
import { useRouter } from 'next/navigation'
import { useAuth } from '../../context/AuthContext'

export default function LoginPage(){
  const [error, setError] = useState('')
  const [remember, setRemember] = useState(false)
  const router = useRouter()
  const { login } = useAuth()

  const handleSubmit = async (e)=>{
    e.preventDefault()
    const form = new FormData(e.target)
    const username = form.get('loginuser')
    const password = form.get('password')
    // Simple validation (replace with API in real project)
    if(username === 'admin' && password === 'admin123'){
      setError('')
      const token = 'fake-token-123' // in real app get from API
      Cookies.set('authToken', token, { expires: remember ? 30 : undefined })
      login({username}, remember)
      router.push('/default')
    } else {
      setError('Credenciais inválidas. Tente novamente.')
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-white dark:bg-gray-800">
      <form onSubmit={handleSubmit} className="bg-gray-50 dark:bg-gray-900 p-8 rounded shadow-md w-full max-w-md">
        <h2 className="text-2xl mb-4 text-gray-800 dark:text-gray-100">Entrar</h2>
        {error && <div className="bg-red-100 text-red-800 p-2 mb-4 rounded">{error}</div>}
        <label className="block mb-2 text-sm">Usuário
          <input name="loginuser" required className="w-full p-2 rounded mt-1" />
        </label>
        <label className="block mb-2 text-sm">Senha
          <input name="password" type="password" required className="w-full p-2 rounded mt-1" />
        </label>
        <label className="flex items-center mt-2">
          <input type="checkbox" checked={remember} onChange={()=>setRemember(r=>!r)} className="mr-2" />
          Lembrar-me
        </label>
        <button type="submit" className="mt-4 w-full p-2 bg-blue-600 text-white rounded">Entrar</button>
      </form>
    </div>
  )
}
