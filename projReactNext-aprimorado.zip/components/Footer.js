import React from 'react'
export default function Footer(){
  return (
    <footer className="bg-gray-100 dark:bg-gray-900 text-gray-700 dark:text-gray-200 p-4 mt-8">
      <div className="container mx-auto text-center">
        © {new Date().getFullYear()} Meu App - Todos os direitos reservados
      </div>
    </footer>
  )
}
