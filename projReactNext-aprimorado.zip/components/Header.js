'use client'
import { useRouter } from 'next/navigation'
import React from 'react'

export default function Header({onLogout}){
  const router = useRouter()
  return (
    <header className="bg-blue-600 text-white p-4">
      <div className="container mx-auto flex justify-between items-center">
        <h1 className="text-xl font-bold cursor-pointer" onClick={()=>router.push('/')}>Meu App</h1>
        <nav>
          <button onClick={()=>router.push('/')} className="mr-4 hover:underline">Home</button>
          <button onClick={()=>router.push('/default')} className="mr-4 hover:underline">Dashboard</button>
          <button onClick={onLogout} className="hover:underline">Sair</button>
        </nav>
      </div>
    </header>
  )
}
