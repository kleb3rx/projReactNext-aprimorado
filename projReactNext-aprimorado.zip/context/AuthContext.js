'use client'
import React, { createContext, useContext, useState, useEffect } from 'react'

const AuthContext = createContext()

export function useAuth(){ return useContext(AuthContext) }

export function AuthProvider({children}){
  const [user, setUser] = useState(null)
  useEffect(()=>{
    try{
      const s = typeof window !== 'undefined' && localStorage.getItem('authUser')
      if(s) setUser(JSON.parse(s))
    }catch(e){}
  },[])
  const login = ({username}, remember)=>{
    const u = {username}
    setUser(u)
    if(remember && typeof window !== 'undefined') localStorage.setItem('authUser', JSON.stringify(u))
  }
  const logout = ()=>{
    setUser(null)
    if(typeof window !== 'undefined') localStorage.removeItem('authUser')
  }
  return (
    <AuthContext.Provider value={{user, login, logout}}>
      {children}
    </AuthContext.Provider>
  )
}
