# Sistema de Autenticação Next.js Aprimorado (modificado automaticamente)

## O que foi implementado
- Validação de credenciais (usuário: `admin`, senha: `admin123`) com mensagens de erro.
- Componente `Header`, `Footer` e `Loading` adicionados em `/components`.
- Sistema de tema claro/escuro via `ThemeContext` (persistência em localStorage).
- Contexto de autenticação `AuthContext` com persistência em `localStorage` quando 'Lembrar-me' está ativo.
- Hook `useRequireAuth` em `/hooks` para proteger páginas.
- Página principal com 3 seções e botão de alternância de tema.
- Página `/default` criada como área protegida.
- README atualizado automaticamente.

## Como executar
1. Instale dependências (no diretório do projeto):
```
npm install
```
2. Execute o projeto:
```
npm run dev
```
3. Acesse em: http://localhost:3000
4. Credenciais de teste: usuário `admin`, senha `admin123`

## Observações
- Este projeto foi modificado automaticamente pelo assistente para atender às solicitações da atividade. Verifique os arquivos e ajuste conforme necessário.
- Em produção, substitua a autenticação front-end por um back-end seguro e tokens reais.
